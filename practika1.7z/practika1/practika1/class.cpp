#include "class.h"

using namespace std;

#define Pi 3.1416

//constructor
Circle::Circle()
{
     Radius = 1;
     Ference = 2 * Pi;
	 Area = Pi;
}

Circle::Circle(double a) 
{
    Radius = a;
    Ference = 2 * Pi * Radius;
    Area = Ference * Radius / 2;
}


void Circle::SetRadius(double a) 
{
    Radius = a;
    Ference = 2 * Pi * Radius;
    Area = Ference*Radius / 2;
}
double Circle::GetRadius() const 
{
    return Radius;
}


void Circle::SetFerence(double a) 
{
    Ference = a;
    Radius = Ference / (2 * Pi);
    Area = Ference*Radius / 2;
}
double Circle::GetFerence() const 
{
    return Ference;
}


void Circle::SetArea(double a) 
{
    Area = a;
    Radius = sqrt(Area / Pi);
    Ference = 2 * Pi * Radius;
}
double Circle::GetArea() const 
{
    return Area;
}


/*Circle::~Circle()
{

}*/
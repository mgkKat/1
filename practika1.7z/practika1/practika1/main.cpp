#include "class.h"
using namespace std;

int main() {

	Circle circle1(6378.1);

	Circle circle2;
	circle2.SetFerence(circle1.GetFerence() + 1);

	cout << "distinction " << circle2.GetRadius() - circle1.GetRadius() << endl;

	Circle circle3(3);
	Circle circle4(4);

	double doroga = (circle4.GetArea() - circle3.GetArea()) * 1000;
	double ograda = circle4.GetFerence() * 2000;
	double itogo = doroga + ograda;

		cout << "\n Price of the walkway " << doroga << endl;
		cout << "Fence price " << ograda << endl;
		cout << "Price for all " << itogo << endl;

	_getch();
	return 0;
}


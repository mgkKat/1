#ifndef AUTOMATADEMO_AUTOMATA_H
#define AUTOMATADEMO_AUTOMATA_H

#define MENU_SIZE 9

class Automata {
public:
    void run();
	Automata()
	{
		menu[1]="�����1";
		menu[2]="���e�2";
		menu[3]="�����3";
		menu[4]="���1";
		menu[5]="���2";
		menu[6]="���3";
		menu[7]="����1"; 
		menu[8]="����2";
		menu[9]="����3";

		price[1]=50;
		price[2]=51;
		price[3]=52;
		price[4]=53;
		price[5]=54;
		price[6]=55;
		price[7]=56;
		price[8]=57;
		price[9]=58;

		

	};

private:
    enum STATE {OFF, WAIT, ACCEPT, CHOOSE};
    float balance;
    char* menu[MENU_SIZE]; 
    int price[MENU_SIZE];
    int state;

    void on();
    void off();
    void deposit(float);
    void printMenu();
    void printState();
    void check(int);
    void cook(int);
    void returnOdd();
};

#endif 
#include "Automata.h"
#include <iostream>

int main() {
   
	setlocale(LC_CTYPE, "Russian");
	
	Automata automataDemo;
    automataDemo.run();
    
    return 0;
}